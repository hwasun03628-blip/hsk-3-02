합격킹 HSK · 화선쌤 속사포 0-3급 · HSK 3급 필수단어 [2]

GitHub 업로드 방법:
1. GitHub에서 새 공개 저장소 hsk-quiz-10을 만듭니다.
2. ZIP 압축을 풀고 index.html, preview.svg 파일을 저장소 최상위에 업로드합니다.
3. Settings > Pages > Build and deployment에서 Deploy from a branch, main, /(root)를 선택하고 Save 합니다.
4. 게시 주소: https://hwasun03628-blip.github.io/hsk-quiz-10/
5. 카카오톡 미리보기는 GitHub Pages 공개 후 확인하세요. 기존에 공유한 주소는 카카오톡 캐시 때문에 갱신이 늦을 수 있습니다.

발음은 브라우저의 중국어 음성합성(TTS)을 사용합니다. 기기/브라우저의 중국어 음성 설치 여부에 따라 음질이 달라집니다.
카카오톡 미리보기 이미지에 SVG를 지원하지 않는 환경에서는 제목과 설명만 나타날 수 있습니다.
